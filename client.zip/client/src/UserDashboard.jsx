// UserDashboard.jsx
import React from 'react';

function UserDashboard() {
    return (
        <div>
            <h2>Welcome to User Dashboard</h2>
            {/* Add user-specific content here */}
        </div>
    );
}

export default UserDashboard;
