import React, { useState } from 'react';

const AdminDashboard = () => {
  // State to store faculty members
  const [facultyMembers, setFacultyMembers] = useState([]);
  // State to manage form inputs
  const [formData, setFormData] = useState({
    name: '',
    designation: ''
  });

  // Function to handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Function to handle adding a new faculty member
  const handleAddFacultyMember = () => {
    if (formData.name && formData.designation) {
      setFacultyMembers([
        ...facultyMembers,
        { name: formData.name, designation: formData.designation }
      ]);
      // Clear the form inputs after adding a faculty member
      setFormData({ name: '', designation: '' });
    }
  };

  // Function to handle removing a faculty member
  const handleRemoveFacultyMember = (index) => {
    const updatedFacultyMembers = [...facultyMembers];
    updatedFacultyMembers.splice(index, 1);
    setFacultyMembers(updatedFacultyMembers);
  };

  return (
    <div>
      <h1>Admin Dashboard</h1>
      <div>
        <h2>Add Faculty Member</h2>
        <input
          type="text"
          placeholder="Name"
          name="name"
          value={formData.name}
          onChange={handleInputChange}
        />
        <input
          type="text"
          placeholder="Designation"
          name="designation"
          value={formData.designation}
          onChange={handleInputChange}
        />
        <button onClick={handleAddFacultyMember}>Add</button>
      </div>
      <div>
        <h2>Faculty Members</h2>
        <ul>
          {facultyMembers.map((facultyMember, index) => (
            <li key={index}>
              {facultyMember.name} - {facultyMember.designation}
              <button onClick={() => handleRemoveFacultyMember(index)}>Remove</button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default AdminDashboard;
